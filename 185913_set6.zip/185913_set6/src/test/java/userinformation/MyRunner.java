package userinformation;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\ajpadala\\Desktop\\ab\\185913_set5\\src\\test\\resources\\userInformation\\userInformatio.feature")
public class MyRunner {

}
