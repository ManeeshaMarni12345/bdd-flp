package factoryFiles;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RegistrationForm {

	WebDriver driver;

	@FindBy(name = "txtbrand_id")
	@CacheLookup
	WebElement brand_id;

	
	
	@FindBy(how = How.ID, using = "txtName")
	@CacheLookup
	WebElement name;

	@FindBy(how = How.ID, using = "txtcategory")
	@CacheLookup
	WebElement category;

	@FindBy(how=How.ID,using = "txtdescription")
	@CacheLookup
	WebElement description;

	@FindBy(name = "txtprice")
	@CacheLookup
	WebElement price;
	
	@FindBy(how=How.ID, using="btnSubmit")
	@CacheLookup
	WebElement confirmButton;

	@FindBy(how = How.ID, using = "discount")
	@CacheLookup
	WebElement discount;

	@FindBy(name = "txtquantity")
	@CacheLookup
	WebElement quantity;

	@FindBy(how = How.NAME, using = "charges")
	@CacheLookup
	WebElement charges;

	@FindBy(name = "txttax")
	@CacheLookup
	WebElement tax;

	@FindBy(how = How.NAME, using = "promo")
	@CacheLookup
	WebElement promo;
	
	


	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getBrand_id() {
		return brand_id;
	}

	public void setBrand_id(WebElement brand_id) {
		this.brand_id = brand_id;
	}

	public WebElement getName() {
		return name;
	}

	public void setName(WebElement name) {
		this.name = name;
	}

	public WebElement getCategory() {
		return category;
	}

	public void setCategory(WebElement category) {
		this.category = category;
	}

	public WebElement getDescription() {
		return description;
	}

	public void setDescription(WebElement description) {
		this.description = description;
	}

	public WebElement getPrice() {
		return price;
	}

	public void setPrice(WebElement price) {
		this.price = price;
	}

	public WebElement getConfirmButton() {
		return confirmButton;
	}

	public void setConfirmButton(WebElement confirmButton) {
		this.confirmButton = confirmButton;
	}

	public WebElement getDiscount() {
		return discount;
	}

	public void setDiscount(WebElement discount) {
		this.discount = discount;
	}

	public WebElement getQuantity() {
		return quantity;
	}

	public void setQuantity(WebElement quantity) {
		this.quantity = quantity;
	}

	public WebElement getCharges() {
		return charges;
	}

	public void setCharges(WebElement charges) {
		this.charges = charges;
	}

	public WebElement getTax() {
		return tax;
	}

	public void setTax(WebElement tax) {
		this.tax = tax;
	}

	public WebElement getPromo() {
		return promo;
	}

	public void setPromo(WebElement promo) {
		this.promo = promo;
	}

	public RegistrationForm(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void choose(String string) {
		// TODO Auto-generated method stub
		
	}

}
