package factoryFiles;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Add {

	WebDriver driver;

	@FindBy(how = How.NAME, using = "brand_id")
	@CacheLookup
	WebElement brand_id;

	@FindBy(how = How.NAME, using = "name")
	@CacheLookup
	String name;

	@FindBy(how = How.NAME, using = "category")
	@CacheLookup
	String category;

	@FindBy(how = How.NAME, using = "description")
	@CacheLookup
	String description;

	@FindBy(how = How.NAME, using = "price")
	@CacheLookup
	String price;

	@FindBy(how = How.NAME, using = "discount")
	@CacheLookup
	String discount;

	@FindBy(how = How.NAME, using = "charge")
	@CacheLookup
	String charge;

	@FindBy(how = How.NAME, using = "promo")
	@CacheLookup
	String promo;

	@FindBy(how = How.NAME, using = "quantity")
	@CacheLookup
	String quantity;

	@FindBy(how = How.NAME, using = "tax")
	@CacheLookup
	String tax;

	@FindBy(className = "submit-btn")
	@CacheLookup
	WebElement submit;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getBrand_id() {
		return brand_id;
	}

	public void setBrand_id(WebElement brand_id) {
		this.brand_id = brand_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getDiscount() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public String getCharge() {
		return charge;
	}

	public void setCharge(String charge) {
		this.charge = charge;
	}

	public String getPromo() {
		return promo;
	}

	public void setPromo(String promo) {
		this.promo = promo;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getTax() {
		return tax;
	}

	public void setTax(String tax) {
		this.tax = tax;
	}

	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit(WebElement submit) {
		this.submit = submit;
	}

	public Add(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}


	public void setSubmit(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setBrand_id(String string) {
		// TODO Auto-generated method stub
		
	}

}
