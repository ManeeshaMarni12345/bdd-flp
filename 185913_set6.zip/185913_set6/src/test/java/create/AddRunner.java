package create;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="D:\\Users\\mamarni\\0475\\185913_set6\\src\\test\\resources\\ create\\create.feature")
public class AddRunner {

}
