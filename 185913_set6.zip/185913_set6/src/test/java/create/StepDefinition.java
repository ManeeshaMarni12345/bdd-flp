package create;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import factoryFiles.Add;

public class StepDefinition {

	WebDriver driver;
	private Add add;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\mamarni\\chromedriver_win32\\chromedriver.exe");

		driver = new ChromeDriver();
	}

	@Given("^admin is on product adding page$")
	public void admin_is_on_product_adding_page() throws Throwable {
		driver.get("D:\\Users\\mamarni\\0475\\185913_set6\\create.component.html");
		add = new Add(driver);
		
	}

	@When("^user enters invalid brand_id$")
	public void user_enters_invalid_brand_id() throws Throwable {
		add.setBrand_id("");
		add.setSubmit("");

	}

	@Then("^displays 'brand_id is required'$")
	public void displays_brand_id_is_required() throws Throwable {
		String expectedMessage=("*brand_id is required");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {
		
		add.setBrand_id("121");
		add.setName("");
		add.setSubmit("");
		
	}

	@Then("^displays 'Please fill the name'$")
	public void displays_Please_fill_the_name() throws Throwable {
		String expectedMessage=("*Name is required");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
		
	}

	@When("^user enters invalid category$")
	public void user_enters_invalid_category() throws Throwable {
		
		add.setBrand_id("121");
		add.setName("puma");
		add.setCategory("");
		add.setSubmit("");
		
	}

	@Then("^displays 'Please fill the category'$")
	public void displays_Please_fill_the_category() throws Throwable {
		String expectedMessage=("*Category is required");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid description$")
	public void user_enters_invalid_description() throws Throwable {
		add.setBrand_id("121");
		add.setName("puma");
		add.setCategory("shirt");
		add.setDescription("");
		add.setSubmit("");
	}

	@Then("^displays 'Please fill the description'$")
	public void displays_Please_fill_the_description() throws Throwable {
		String expectedMessage=("*Description is required");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid price$")
	public void user_enters_invalid_price() throws Throwable {	
	add.setBrand_id("121");
	add.setName("puma");
	add.setCategory("shirt");
	add.setDescription("cotton");
	add.setPrice("");
	add.setSubmit("");
	}

	@Then("^displays 'Please fill the price'$")
	public void displays_Please_fill_the_price() throws Throwable {
		String expectedMessage=("*Price is required");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid discount$")
	public void user_enters_invalid_discount() throws Throwable {
		add.setBrand_id("121");
		add.setName("puma");
		add.setCategory("shirt");
		add.setDescription("cotton");
		add.setPrice("1000");
		add.setDiscount("");
		add.setSubmit("");
	}

	@Then("^displays 'Please fill the discount'$")
	public void displays_Please_fill_the_discount() throws Throwable {
		String expectedMessage=("*Discount is required");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid quantity$")
	public void user_enters_invalid_quantity() throws Throwable {
		add.setBrand_id("121");
		add.setName("puma");
		add.setCategory("shirt");
		add.setDescription("cotton");
		add.setPrice("1000");
		add.setDiscount("10");
		add.setQuantity("");
		add.setSubmit("");
	}

	@Then("^displays 'Please fill the quantity'$")
	public void displays_Please_fill_the_quantity() throws Throwable {
		String expectedMessage=("*Quantity is required");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid charges$")
	public void user_enters_invalid_charges() throws Throwable {
		add.setBrand_id("121");
		add.setName("puma");
		add.setCategory("shirt");
		add.setDescription("cotton");
		add.setPrice("1000");
		add.setDiscount("10");
		add.setQuantity("8");
		add.setCharge("");
		add.setSubmit("");
	}

	@Then("^displays 'Please fill the charges'$")
	public void displays_Please_fill_the_charges() throws Throwable {
		String expectedMessage=("*Charges is required");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid tax$")
	public void user_enters_invalid_tax() throws Throwable {
		add.setBrand_id("121");
		add.setName("puma");
		add.setCategory("shirt");
		add.setDescription("cotton");
		add.setPrice("1000");
		add.setDiscount("10");
		add.setQuantity("8");
		add.setCharge("45");
		add.setTax("");
		add.setSubmit("");
	}

	@Then("^displays 'Please fill the tax'$")
	public void displays_Please_fill_the_tax() throws Throwable {
		String expectedMessage=("*Tax is required");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid promo$")
	public void user_enters_invalid_promo() throws Throwable {
		add.setBrand_id("121");
		add.setName("puma");
		add.setCategory("shirt");
		add.setDescription("cotton");
		add.setPrice("1000");
		add.setDiscount("10");
		add.setQuantity("8");
		add.setCharge("45");
		add.setTax("10");
		add.setPromo("");
		add.setSubmit("");
	
	}

	@Then("^displays 'Please fill the promo'$")
	public void displays_Please_fill_the_promo() throws Throwable {
		String expectedMessage=("*Promo is required");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		add.setBrand_id("121");
		add.setName("puma");
		add.setCategory("shirt");
		add.setDescription("cotton");
		add.setPrice("1000");
		add.setDiscount("10");
		add.setQuantity("8");
		add.setCharge("45");
		add.setTax("10");
		add.setPromo("10");
		add.setSubmit("");
	}

	@Then("^products are added to database$")
	public void products_are_added_to_database() throws Throwable {
		 System.out.println("Product Added successfully");
	}

}
