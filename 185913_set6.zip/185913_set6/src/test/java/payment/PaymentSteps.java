package payment;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import factoryFiles.PaymentForm;
import factoryFiles.RegistrationForm;

public class PaymentSteps {
	
	WebDriver driver;
	private PaymentForm paymentForm;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\mamarni\\chromedriver_win32\\chromedriver.exe");
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\mamarni\\chromedriver_win32.chromedriver.exe");

		
		driver= new ChromeDriver();
	}
	@Given("^user is on 'payment' page$")
	public void user_is_on_payment_page() throws Throwable {
		driver.get("C:\\Users\\ajpadala\\Desktop\\ab\\185913_set5\\PaymentDetails.html");
		paymentForm= new PaymentForm(driver);
	}

	@When("^user enters invalid cardHolder name$")
	public void user_enters_invalid_cardHolder_name() throws Throwable {
		paymentForm.setCardHolderName("");
		paymentForm.setConfirmButton("");
	}

	@Then("^displays 'Please fill the CardHolder Name'$")
	public void displays_Please_fill_the_CardHolder_Name() throws Throwable {
		String expectedMessage=("Please fill the Card holder name");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid card number$")
	public void user_enters_invalid_card_number() throws Throwable {
		paymentForm.setCardHolderName("ajay");
		paymentForm.setCardNumber("");
		paymentForm.setConfirmButton("");
	}

	@Then("^displays 'Please fill the card number'$")
	public void displays_Please_fill_the_card_number() throws Throwable {
		String expectedMessage=("Please fill the Debit card Number");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
		
		
	}

	@When("^user enters invalid CVV$")
	public void user_enters_invalid_CVV() throws Throwable {
		paymentForm.setCardHolderName("ajay");
		paymentForm.setCardNumber("123456");
		paymentForm.setCVV("");
		paymentForm.setConfirmButton("");
		
	}

	@Then("^displays 'Please fill the CVV'$")
	public void displays_Please_fill_the_CVV() throws Throwable {
		String expectedMessage=("Please fill the CVV");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	
	@When("^user enters invalid Exp number$")
	public void user_enters_invalid_Emp_number() throws Throwable {
		paymentForm.setCardHolderName("ajay");
		paymentForm.setCardNumber("123456");
		paymentForm.setCVV("4568");
		paymentForm.setExpMonth("");
		paymentForm.setConfirmButton("");
	}

	@Then("^displays 'Please fill the Exp month number'$")
	public void displays_Please_fill_the_Exp_month_number() throws Throwable {
		String expectedMessage=("Please fill expiration month");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^user enters invalid Exp year$")
	public void user_enters_invalid_Exp_year() throws Throwable {
		paymentForm.setCardHolderName("ajay");
		paymentForm.setCardNumber("123456");
		paymentForm.setCVV("4568");
		paymentForm.setExpMonth("12");
		paymentForm.setExpYear("");
		paymentForm.setConfirmButton("");
	}

	@Then("^displays 'Please fill the Exp year'$")
	public void displays_Please_fill_the_Exp_year() throws Throwable {
		String expectedMessage=("Please fill the expiration year");
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	    
	   
	}

	@When("^user enters all valid details$")
	public void user_enters_all_valid_details() throws Throwable {
		paymentForm.setCardHolderName("ajay");
		paymentForm.setCardNumber("123456");
		paymentForm.setCVV("4568");
		paymentForm.setExpMonth("12");
		paymentForm.setExpYear("22");
		paymentForm.setConfirmButton("");
	}

	@Then("^displays 'Congrats! Payment success'$")
	public void displays_Congrats_Payment_success() throws Throwable {
	    System.out.println("Payment Successful");
	}

	

}
